package com.zybooks.weightlogv2.model.MainModels;

public class GoalWeightModel {
    private double goalWeight;

    public GoalWeightModel(double goalWeight) {
        this.goalWeight = goalWeight;
    }

    public double getGoalWeight(){
        return this.goalWeight;
    }
}
